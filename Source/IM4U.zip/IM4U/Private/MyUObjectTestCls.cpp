// Copyright 2015 BlackMa9. All Rights Reserved.

#include "MyUObjectTestCls.h"
#include "IM4UPrivatePCH.h"

UMyUObjectTestCls::UMyUObjectTestCls(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}