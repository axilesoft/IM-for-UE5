// Copyright 2015 BlackMa9. All Rights Reserved.

#include "MMDExtendAsset.h"
#include "IM4UPrivatePCH.h"

UMMDExtendAsset::UMMDExtendAsset(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}